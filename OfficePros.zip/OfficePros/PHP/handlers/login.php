<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    try {
        $pdo = new PDO("mysql:host=127.0.0.1;dbname=tjllew", "tjllew", "yayeet123");
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $query = "SELECT ID, UserType FROM tjllew.users WHERE UserEmail = :username AND Password = :password";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':password', $password);
        $stmt->execute();

        if ($stmt->rowCount() == 1) {
            $row = $stmt->fetch();
            $user_id = $row['ID'];
            $userType = $row['UserType'];

            if ($userType == 'admin') {
                // The user is an admin
                $_SESSION["user_id"] = $user_id;
                $_SESSION["username"] = $username;
                header("Location: admin_profile.php");
                exit();
            } else {
                // The user is a regular user
                $_SESSION["user_id"] = $user_id;
                $_SESSION["username"] = $username;
                header("Location: profile.php");
                exit();
            }
        } else {
            // Invalid login, display an error message
            echo "Invalid login credentials";
        }
    } catch (PDOException $e) {
        echo "Database error: " . $e->getMessage();
    }
}
