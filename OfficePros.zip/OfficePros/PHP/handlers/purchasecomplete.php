<?php
session_start();
$productID = array();

//connect to database
$connect = mysqli_connect("127.0.0.1","tjllew","yayeet123","tjllew");




if(isset($_POST['submit'])) {
    foreach($_SESSION['cart'] as $input => $product){
        $product_ID = $product['id'];
        $productName = $product['productName'];
        $productPrice = $product['pricePerItem'];
        $productQuantity = $product['quantity'];
        $totalPrice = number_format($product['quantity'] * $product['pricePerItem'], 2);
        $dateOrdered = date("Y-m-d");
        $dateShipped = date('Y-m-d', strtotime("+3 day"));
        $dateRecieved = date('Y-m-d', strtotime("+6 day"));
    
    $useremail = stripslashes($_POST['emailInput']);
    $sql = "SELECT * FROM users WHERE UserEmail = '$useremail'";
    $result = $connect->query($sql);

      if (mysqli_num_rows($result) > 0) {
        while($row = mysqli_fetch_assoc($result)) {
            $OrderID = ($row["ID"] . date("Y") . date("d") . date("H") . date("i"));
            $userID = $row['ID'];
            $userName = $row["FullName"];


            $sqlinsert = "INSERT INTO officepro.orders (OrderId, CustomerID, CustomerName, ProductID, ProductName, Quantity, ItemPrice, TotalPrice, DateOrdered, DateShipped, DateRecieved)
            VALUES ('$OrderID', '$userID', '$userName', '$product_ID', '$productName', '$productPrice', '$productQuantity', '$totalPrice', '$dateOrdered', '$dateShipped', '$dateRecieved')";
            if ($connect->query($sqlinsert) === TRUE) {
                foreach($_SESSION['cart'] as $input => $product){
                        unset($_SESSION['cart'][$input]);
                }
              } else {
                echo "Error: " . $sqlinsert . "<br>" . $connect->error;
              }
        }
    
      } else {
        echo "0 results";
      }
    }



}




?>



<!DOCTYPE html>
<html>
    <title>Purchase Complete</title>
        <head>

        <link rel="stylesheet" href="../../CSS/mainstyles.css" />

        </head>

    <body>
        <div class="center-container">
            <div class = "wrapper-dis">
                <div class = "disclaimer">
                    <H1>Purchase Complete</H1>
                        <p>Thank you for your purchase! Please either navigate back to the homepage, or you can log out if done shopping.
                        </p>
                        
                    <br><br>
                    
                    <a href="../pages/home.php">Home Page</a> <a href="logout.php">Logout</a>

                </div>
            </div>
        </div>
    </body>

</html>