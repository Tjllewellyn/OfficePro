<html>
    <title>Users Registered through Database </title>

    <head>

        <link rel="stylesheet" href="../../CSS/mainstyles.css" />

    </head>

    <body>
       <?php include '../NavbarFooter/nav.php'; ?>
				
				<br><br>
				<a href="../handlers/admin_profile.php">Admin Profile</a>
				<a href="home.php">Admin Home</a>
				<a href="customerorder.php">Products to Order</a>
				<br>
				<h2 style="text-align: center;"> Users Registered through our Database</h2>
			<?php
				//make a DB Connecttion
				$DBConnect = mysqli_connect("127.0.0.1","tjllew","yayeet123","tjllew");

				//if there isn't a DB connection, you need to let the admin know

				if ($DBConnect == false)
					print("Unable to connect to the database: " . mysqli_connect_error());
				else {

					//set up the table name
					$TableContact = "users";
					//
					$SQLstring = "select * from $TableContact";
					$QueryResult = mysqli_query($DBConnect, $SQLstring);
					//check to see if there are record in the table?
					if (mysqli_num_rows($QueryResult) > 0) { //output all of the results in a table
						print "Here is a list of Registered Users";
						print "<table width ='100%' border ='1'>";
						print "<tr>
							<th>FullName</th>
							<th>UserEmail</th>
							<th>UserType</th>
							</tr>";
						while ($Row = mysqli_fetch_assoc($QueryResult)) {

							//this is the dynamic part of out table
							print "<tr>
						<td>{$Row['FullName']}</td>
						<td>{$Row['UserEmail']}</td>
						<td>{$Row['UserType']}</td>
						</tr>";
						} //end while statement
					} //end num row test
					else
						print "there are no results to display";
					mysqli_free_result($QueryResult);
				} //close the cinnection
				mysqli_close($DBConnect);


			?>
			<form method="POST" action = "deletecustomercontent.php">
<p>Delete a Record based on Full Name: <input type = "text" name = "record" /></p>
<p><input type="submit" value="Submit" /></p>
</form>
				
		
    </body>

        

</html>