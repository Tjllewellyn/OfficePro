<html>

<head>

<title>Case List Removed</title>

	<link rel="stylesheet" href="../../CSS/mainstyles.css" />
	
</head>

<body>
 
 <?php include '../NavbarFooter/nav.php'; ?>
 
<h1>Removed</h1>

<h2>Your contact data has been deleted</h2>



<br><br>

<a href="home.php">Admin Page</a>
<p><a href="../adminpages/account-login-logs.php">Login Logs</a></p>
<br>

<?php

//make a DB Connection

		$DBConnect = mysqli_connect("127.0.0.1","tjllew","yayeet123","tjllew");
	
	//if there isn't a DB connection, you need to let the admin know
	
	if($DBConnect === false)
			print"Unable to connection to the database, error number:".mysqli_errno();
			else{
				
					$TableContact = "contactus";
					//********************************************************
					//this is the only new code to delete a records
					$DeleteThis = stripslashes($_POST['record']);
					$SQLString = "delete from $TableContact where CaseNumber = '$DeleteThis'";
					$QueryResult = mysqli_query($DBConnect,$SQLString);
															
					//*********************************************************
									
					$SQLString = "select * from $TableContact";
					$QueryResult = mysqli_query($DBConnect,$SQLString);
					
						if(mysqli_num_rows($QueryResult)> 0)
						{print"Here is a list of your contact information";
						//we are now going to set up the table
						print"Here is a list of Inquries";
						print"<table width ='100%' border='1'>";
						print"<tr>
							<th>CaseNumber</th>
							<th>ContactTimestamp</th>
							<th>FirstName</th>
							<th>LastName</th>
							<th>UserEmail</th>
							<th>Message</th>
							</tr>";
								
						//this is where we make it dynamic
						
						while($Row = mysqli_fetch_assoc($QueryResult))
						{
							print"<tr>
						<td>{$Row['CaseNumber']}</td>
						<td>{$Row['ContactTimestamp']}</td>
						<td>{$Row['FirstName']}</td>
						<td>{$Row['LastName']}</td>
						<td>{$Row['UserEmail']}</td>
						<td>{$Row['Message']}</td>	
						</tr>";
						}//end while statement
						} //end num row test
					else
						print "there are no results to display";
					mysqli_free_result($QueryResult);
				} //close the connection
				mysqli_close($DBConnect);


			?>
			


</body>
</html>