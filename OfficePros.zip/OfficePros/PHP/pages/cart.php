<?php
session_start();
$productID = array();
//session_destroy();

//action for the Add to Cart button
//productCount variable for the number of products that are in the cart
//productID variable for the array of products added to the car
if(filter_input(INPUT_POST, 'add_products')){
    if(isset($_SESSION['cart'])){
        
        $productCount = count($_SESSION['cart']);
        $productID = array_column($_SESSION['cart'], 'id');
        
        //if the product ID is not in the array then post the productName, pricePerItem, and quanity of the product in the array
        //else increase the quantity of the product was found in the array
        if (!in_array(filter_input(INPUT_GET, 'id'), $productID)){
        $_SESSION['cart'][$productCount] = array
            (
                'id' => filter_input(INPUT_GET, 'id'),
                'productName' => filter_input(INPUT_POST, 'productName'),
                'pricePerItem' => filter_input(INPUT_POST, 'pricePerItem'),
                'quantity' => filter_input(INPUT_POST, 'quantity')
            );   
        }
        else { 
            for ($i = 0; $i < count($productID); $i++){
                if ($productID[$i] == filter_input(INPUT_GET, 'id')){
                    $_SESSION['cart'][$i]['quantity'] += filter_input(INPUT_POST, 'quantity');
                }
            }
        }
        
    }
    //if the cart is empty then create the Session cart with the first product starting at index zero
    //add the product to the array
    else {
        $_SESSION['cart'][0] = array
        (
            'id' => filter_input(INPUT_GET, 'id'),
            'productName' => filter_input(INPUT_POST, 'productName'),
            'pricePerItem' => filter_input(INPUT_POST, 'pricePerItem'),
            'quantity' => filter_input(INPUT_POST, 'quantity')
        );
    }
}


//action for the Remove button
//grab the product ID and find it within the array
//once found, remove product and associated attributes from the array using the UNSET function
//repost the updated Session cart
if(filter_input(INPUT_GET, 'action') == 'remove'){
    foreach($_SESSION['cart'] as $key => $product){
        if ($product['id'] == filter_input(INPUT_GET, 'id')){
            unset($_SESSION['cart'][$key]);
        }
    }
    $_SESSION['cart'] = array_values($_SESSION['cart']);
}


?>
<!DOCTYPE html>
<html>
    <head>
        <title>OfficePro Products</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
        <link rel="stylesheet" href="../../CSS/cart.css" />
    </head>
    <body>
    <?php include '../NavbarFooter/nav.php'; ?>
        <div class="container">
        <?php

        $connect = mysqli_connect('127.0.0.1','tjllew','yayeet123','tjllew');
        $query = 'SELECT * FROM products ORDER by id ASC';
        $result = mysqli_query($connect, $query);

        if ($result):
            if(mysqli_num_rows($result)>0):
                while($product = mysqli_fetch_assoc($result)):
                ?>
                <div class="col-sm-4 col-md-3" >
                    <form method="post" action="cart.php?action=add&id=<?php echo $product['ID']; ?>">
                        <div class="products">
                            <img id="imagesize" src="<?php echo $product['image']; ?>" class="img-responsive"/>
                            <h4 class="text-info"><?php echo $product['productName']; ?></h4>
                            <h4>$ <?php echo $product['pricePerItem']; ?></h4>
                            <input type="hidden" name="productName" value="<?php echo $product['productName']; ?>" />
                            <input type="hidden" name="pricePerItem" value="<?php echo $product['pricePerItem']; ?>" />
                            <input type="text" name="quantity" class="form-control" value="1" />
                            <input type="submit" name="add_products" style="margin-top:5px;" class="btn btn-info"
                                   value="Add to Cart" />
                        </div>
                    </form>
                </div>
                <?php
                endwhile;
            endif;
        endif;   
        ?>
        <div style="clear:both"></div>  
        <br />  
        <div class="table-responsive">  
        <table class="table">  
            <tr><th colspan="5"><h3>Shopping Cart</h3></th></tr>   
        <tr>  
             <th width="35%">Product Name</th>  
             <th width="20%">Price Per Item</th>  
             <th width="15%">Quantity</th>  
             <th width="15%">Total Price</th>  
             <th width="5%">Remove</th>  
        </tr>  
        <?php   
        if(!empty($_SESSION['cart'])):  
            
             $totalPrice = 0;  
        
             foreach($_SESSION['cart'] as $key => $product): 
        ?>  
        <tr>  
           <td><?php echo $product['productName']; ?></td>  
           <td>$ <?php echo $product['pricePerItem']; ?></td> 
           <td><?php echo $product['quantity']; ?></td>  
           <td>$ <?php echo number_format($product['quantity'] * $product['pricePerItem'], 2); ?></td>  
           <td>
               <a href="cart.php?action=remove&id=<?php echo $product['id']; ?>">
                    <div class="btn-danger">Remove</div>
               </a>
           </td>  
        </tr>  
        <?php  
                  $totalPrice = $totalPrice + ($product['quantity'] * $product['pricePerItem']);  
             endforeach;  
        ?>  
        <tr>  
             <td colspan="3" align="right">Total</td>  
             <td align="left">$ <?php echo number_format($totalPrice, 2); ?></td>  
             <td></td>  
        </tr>  
        <tr>
            <!-- Only show the Go To Checkout Button if cart is not empty -->
            <td colspan="5">
             <?php 
                if (isset($_SESSION['cart'])):
                if (count($_SESSION['cart']) > 0):
             ?>
                <a href="cartaction.php" class="button">Go To Checkout</a>
             <?php endif; endif; ?>
            </td>
        </tr>
        <?php  
        endif;
        ?>  
        </table>  
         </div>
        </div>
    </body>
    <?php include '../NavbarFooter/footer.php'; ?>
</html>
