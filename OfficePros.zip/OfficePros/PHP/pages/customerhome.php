<html>
	<title>Customer Homepage</title>

	<head>

		<link rel="stylesheet" href="../../CSS/mainstyles.css" />

	</head>

	<body>
		<?php include '../NavbarFooter/nav.php'; ?>

		<h2 style="text-align: center;"> Welcome to our Website!</h2>
		<h2 style="text-align: center;"><a href="../handlers/profile.php">Personal Profile</a></h2>
		



	</body>

	<?php include '../NavbarFooter/footer.php'; ?>

</html>