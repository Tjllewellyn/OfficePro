<?php
session_start();
$productID = array();
//session_destroy();

//action for the Remove button
//grab the product ID and find it within the array
//once found, remove product and associated attributes from the array using the UNSET function
//repost the updated Session cart
if(filter_input(INPUT_GET, 'action') == 'remove'){
    foreach($_SESSION['cart'] as $input => $product){
        if ($product['id'] == filter_input(INPUT_GET, 'id')){
            unset($_SESSION['cart'][$input]);
        }
    }
    $_SESSION['cart'] = array_values($_SESSION['cart']);
}


?>
<!DOCTYPE html>
<html>
    <head>
        <title>OfficePro Products</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
        <link rel="stylesheet" href="../../CSS/cart.css" />
    </head>
    <body>
    <?php include '../NavbarFooter/nav.php'; ?>
        <div class="container">
        <div style="clear:both"></div>  
        <br />  
        
        <div class="table-responsive">  
        <form action="../handlers/purchasecomplete.php" method="post">
        <table class="table">  
            <tr><th colspan="5"><h3>Shopping Cart</h3></th></tr>   
        <tr>  
             <th width="35%">Product Name</th>  
             <th width="20%">Price Per Item</th>  
             <th width="15%">Quantity</th>  
             <th width="15%">Total Price</th>  
             <th width="5%">Remove</th>  
        </tr>  
        <?php   
        if(!empty($_SESSION['cart'])):  
            
             $totalPrice = 0;  
        
             foreach($_SESSION['cart'] as $input => $product): 
        ?>  
        <tr>  
           <td><?php echo $product['productName']; ?></td>  
           <td>$ <?php echo $product['pricePerItem']; ?></td> 
           <td><?php echo $product['quantity']; ?></td>  
           <td>$ <?php echo number_format($product['quantity'] * $product['pricePerItem'], 2); ?></td>  
           <td>
               <a href="cartaction.php?action=remove&id=<?php echo $product['id']; ?>">
                    <div class="btn-danger">Remove</div>
               </a>
           </td>  
        </tr>  
        <?php  
                  $totalPrice = $totalPrice + ($product['quantity'] * $product['pricePerItem']);  
             endforeach;  
        ?>  
        <tr>  
             <td colspan="3" align="right">Total</td>  
             <td align="left">$ <?php echo number_format($totalPrice, 2); ?></td>  
             <td></td>  
        </tr>  
        <tr>
            <td colspan="1">
                <label for="customeremail">Customer Email</label>
                <input type="email" name="emailInput" class="form-control" id="customeremail" placeholder="name@example.com">
            </td>
            <td colspan="5">
                <a href="cart.php" class="button">Back to Shopping</a>
                <input class="button" type="submit" name="submit" value="Purchase" />
            </td>
        </tr>
        <?php  
        endif;
        ?>  
        </table> 
    </form> 
         </div>
        </div>
    </body>
    <?php include '../NavbarFooter/footer.php'; ?>
</html>
